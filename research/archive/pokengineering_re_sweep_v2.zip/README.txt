Pokengineering reverse-engineering sweep v2
============================================

This version expands the previous sweep in two important ways:

1. It analyzes BOTH:
   - runtime ARM9
   - decoded Overlay 3

   Calls between them are followed in the same relationship set.

2. It accepts runtime facts copied from GDB so the report can combine static
   structure with values observed in the live Spearow capture.

Files
-----

tools/re_sweep_v2.py
    Cross-image static/runtime sweep.

runtime_observations.txt
    Pre-filled with the GDB facts observed during the current Spearow trace.
    You can add more REG / MEM8 / MEM16 / MEM32 facts later.

Run it
------

From the Pokengineering repo root:

python3 tools/re_sweep_v2.py \
  --overlay work/code_analysis/executables/overlays/overlay_003.bin \
  --base 0x020D00C0 \
  --arm9 work/code_analysis/runtime/arm9_runtime.bin \
  --arm9-base 0x02000000 \
  --before /tmp/starly_full_before.bin \
  --during /tmp/starly_full_during.bin \
  --runtime-facts runtime_observations.txt \
  --keyword Capture \
  --keyword CapturePokemon \
  --keyword LoadCapturePokemon \
  --keyword CaptureBeforeState \
  --seed 0x02106744 \
  --seed 0x02117258 \
  --seed 0x02117388 \
  --seed 0x02041F5C \
  --out work/re_sweep_v2/reverse_engineering_report_v2.md

Expected output
---------------

work/re_sweep_v2/reverse_engineering_report_v2.md
work/re_sweep_v2/arm9.asm
work/re_sweep_v2/overlay.asm

Upload reverse_engineering_report_v2.md back into ChatGPT.

Runtime facts format
--------------------

One fact per line:

REG pc=0x02117258
REG lr=0x02106ABC
REG r0=0x0213482C
MEM32 0x02134A30=0x00000001
MEM16 0x02126570=0x000D

Comments begin with #.

Notes
-----

- Requires arm-none-eabi-objdump in PATH.
- Uses runtime ARM9 because the on-disk ARM9 did not match the live executable
  sufficiently for this analysis.
- The report can be large. If it becomes unwieldy, remove broad keywords such
  as "Pokemon" and keep Capture-specific keywords/seeds.
- False positives remain possible because objdump -D interprets data as code.
  High-confidence direct-call/literal relationships are more trustworthy than
  heuristic pointer-table/RTTI proximity matches.
