#!/usr/bin/env python3
"""
re_sweep_v2.py — cross-image ARM9 + overlay reverse-engineering sweep.

Designed for Nintendo DS reverse engineering where runtime ARM9 and one decoded
overlay are both available. It combines:
  * ARM disassembly of both images
  * direct cross-image call edges
  * PC-relative literal recovery
  * raw pointer/table scanning
  * string / RTTI-ish extraction
  * basic ARM jump-table switch recovery
  * optional before/during RAM diff
  * runtime observations captured from GDB
  * fixed-point expansion around seeds/runtime code addresses
  * a single Markdown report suitable for feeding back into ChatGPT

This is static analysis with heuristics. It intentionally reports confidence and
does not pretend that every detected function/table is genuine code.
"""

from __future__ import annotations

import argparse
import dataclasses
import re
import struct
import subprocess
import sys
from collections import defaultdict, deque
from pathlib import Path
from typing import Dict, List, Optional, Tuple, Set, Iterable

@dataclasses.dataclass(frozen=True)
class Image:
    name: str
    path: Path
    base: int
    data: bytes

    @property
    def end(self) -> int:
        return self.base + len(self.data)

    def contains(self, addr: int, size: int = 1) -> bool:
        return self.base <= addr and addr + size <= self.end

    def off(self, addr: int) -> int:
        return addr - self.base

    def u8(self, addr: int) -> int:
        return self.data[self.off(addr)]

    def u16(self, addr: int) -> int:
        return struct.unpack_from("<H", self.data, self.off(addr))[0]

    def u32(self, addr: int) -> int:
        return struct.unpack_from("<I", self.data, self.off(addr))[0]

@dataclasses.dataclass
class Insn:
    addr: int
    word: str
    mnemonic: str
    operands: str
    text: str
    image: str

@dataclasses.dataclass
class Edge:
    src: int
    kind: str
    dst: int
    confidence: float
    note: str = ""

@dataclasses.dataclass
class RuntimeFact:
    kind: str
    key: str
    addr: Optional[int]
    value: int
    width: Optional[int]
    raw: str

HEX = r"(?:0x)?[0-9a-fA-F]+"
INSN_RE = re.compile(r"^\s*([0-9a-fA-F]+):\s+([0-9a-fA-F]{8})\s+([a-zA-Z0-9.]+)\s*(.*?)\s*$")
CALL_RE = re.compile(r"^(bl|blx)\s+(0x[0-9a-fA-F]+)$")
LDR_PC_RE = re.compile(r"^ldr(?:[a-z]{0,2})?\s+(r(?:1[0-5]|[0-9])|ip|lr),\s*\[pc,\s*#(-?\d+)\](?:\s+@.*)?$", re.I)
PUSH_LR_RE = re.compile(r"^push\s+\{[^}]*\blr\b[^}]*\}", re.I)
STMFD_LR_RE = re.compile(r"^stm(?:fd|db)\s+sp!,\s*\{[^}]*\blr\b[^}]*\}", re.I)
ADD_PC_SWITCH_RE = re.compile(r"^addls\s+pc,\s*pc,\s*(r(?:1[0-5]|[0-9])),\s*lsl\s*#2$", re.I)
CMP_IMM_RE = re.compile(r"^cmp\s+(r(?:1[0-5]|[0-9])),\s*#(\d+)$", re.I)
BRANCH_RE = re.compile(r"^b(?:[a-z]{0,2})?\s+(0x[0-9a-fA-F]+)$", re.I)
RET_LITERAL_RE = re.compile(r"^ldr\s+r0,\s*\[pc,\s*#(-?\d+)\]", re.I)

def parse_int(s: str) -> int:
    return int(s, 0)

def run_objdump(img: Image, objdump: str) -> str:
    cmd = [
        objdump, "-D", "-b", "binary", "-m", "arm",
        f"--adjust-vma=0x{img.base:08x}", str(img.path)
    ]
    try:
        p = subprocess.run(cmd, check=True, text=True, capture_output=True)
    except FileNotFoundError:
        raise SystemExit(f"ERROR: {objdump!r} not found. Install arm-none-eabi-binutils.")
    except subprocess.CalledProcessError as e:
        print(e.stdout, file=sys.stderr)
        print(e.stderr, file=sys.stderr)
        raise SystemExit(f"ERROR: objdump failed for {img.path}")
    return p.stdout

def parse_disassembly(text: str, image_name: str) -> Dict[int, Insn]:
    out: Dict[int, Insn] = {}
    for line in text.splitlines():
        m = INSN_RE.match(line)
        if not m:
            continue
        addr = int(m.group(1), 16)
        word = m.group(2)
        mnemonic = m.group(3).lower()
        ops = m.group(4).strip()
        full = f"{mnemonic} {ops}".strip()
        out[addr] = Insn(addr, word, mnemonic, ops, full, image_name)
    return out

def find_image(images: List[Image], addr: int, size: int = 1) -> Optional[Image]:
    for img in images:
        if img.contains(addr, size):
            return img
    return None

def classify_addr(images: List[Image], addr: int, ram_lo: int, ram_hi: int) -> str:
    img = find_image(images, addr)
    if img:
        return img.name.upper()
    if ram_lo <= addr < ram_hi:
        return "RAM"
    return "OTHER"

def extract_strings(img: Image, min_len: int = 4) -> Dict[int, str]:
    out = {}
    b = img.data
    i = 0
    while i < len(b):
        if 32 <= b[i] <= 126:
            j = i
            while j < len(b) and 32 <= b[j] <= 126:
                j += 1
            if j - i >= min_len:
                s = b[i:j].decode("ascii", errors="replace")
                out[img.base + i] = s
            i = j + 1
        else:
            i += 1
    return out

def looks_rtti(s: str) -> bool:
    # CodeWarrior-style length-prefixed class names, e.g. 22CSkyCaptureBeforeState
    return bool(re.match(r"^\d+C[A-Za-z_][A-Za-z0-9_:<>]*$", s))

def detect_functions(insns: Dict[int, Insn]) -> Set[int]:
    starts = set()
    for addr, ins in insns.items():
        t = ins.text
        if PUSH_LR_RE.match(t) or STMFD_LR_RE.match(t):
            starts.add(addr)
    # Direct branch-with-link targets are also good function candidates.
    for ins in insns.values():
        m = CALL_RE.match(ins.text)
        if m:
            starts.add(int(m.group(2), 16))
    return starts

def owner_function(functions: Set[int], addr: int) -> Optional[int]:
    # Small enough for this use. Callers cache this externally if needed.
    candidates = [f for f in functions if f <= addr]
    return max(candidates) if candidates else None

def direct_call_edges(insns: Dict[int, Insn], functions: Set[int]) -> Tuple[List[Edge], Dict[int,List[Tuple[int,int]]]]:
    edges = []
    callers = defaultdict(list)
    for addr, ins in insns.items():
        m = CALL_RE.match(ins.text)
        if not m:
            continue
        dst = int(m.group(2), 16)
        src = owner_function(functions, addr) or addr
        edges.append(Edge(src, "DIRECT_CALL", dst, 1.00, f"callsite 0x{addr:08X}"))
        callers[dst].append((src, addr))
    return edges, callers

def literal_edges(images: List[Image], insns: Dict[int, Insn], functions: Set[int]) -> List[Edge]:
    edges = []
    for addr, ins in insns.items():
        m = LDR_PC_RE.match(ins.text)
        if not m:
            continue
        imm = int(m.group(2))
        lit_addr = (addr + 8 + imm) & 0xFFFFFFFF
        img = find_image(images, lit_addr, 4)
        if not img:
            continue
        src = owner_function(functions, addr) or addr
        val = img.u32(lit_addr)
        edges.append(Edge(src, "LOAD_LITERAL", lit_addr, 0.99, f"insn 0x{addr:08X}"))
        edges.append(Edge(lit_addr, "LITERAL_VALUE", val, 0.99, f"0x{val:08X}"))
    return edges

def scan_pointer_runs(images: List[Image], executable_ranges: List[Tuple[int,int]], min_run: int = 2) -> Tuple[Set[int], List[Edge]]:
    def plausible(v: int) -> bool:
        if any(lo <= v < hi for lo, hi in executable_ranges):
            return True
        # RTTI/data pointers into our loaded images are also useful.
        return find_image(images, v) is not None

    tables = set()
    edges = []
    for img in images:
        i = 0
        n = len(img.data)
        while i + 4 <= n:
            start = i
            vals = []
            while i + 4 <= n:
                v = struct.unpack_from("<I", img.data, i)[0]
                if plausible(v):
                    vals.append((i, v))
                    i += 4
                else:
                    break
            if len(vals) >= min_run:
                taddr = img.base + start
                tables.add(taddr)
                for off, v in vals:
                    edges.append(Edge(taddr, "TABLE_ENTRY", v, 0.90, f"+0x{off-start:X}"))
            if i == start:
                i += 4
    return tables, edges

def raw_pointer_edges(images: List[Image]) -> List[Edge]:
    edges = []
    for img in images:
        for off in range(0, len(img.data) - 3, 4):
            v = struct.unpack_from("<I", img.data, off)[0]
            if find_image(images, v):
                edges.append(Edge(img.base + off, "DATA_POINTER", v, 0.72))
    return edges

def rtti_table_edges(strings: Dict[int,str], tables: Set[int]) -> List[Edge]:
    edges = []
    for saddr, s in strings.items():
        if not looks_rtti(s):
            continue
        # CodeWarrior RTTI/vtables tend to cluster tightly.
        nearby = sorted((abs(t-saddr), t) for t in tables if 0 < t-saddr <= 0x120)
        for dist, t in nearby[:3]:
            edges.append(Edge(saddr, "RTTI_NEAR_TABLE", t, 0.78, f"{s}, distance 0x{dist:X}"))
    return edges

def detect_switches(images: List[Image], insns: Dict[int,Insn], functions: Set[int]) -> Tuple[List[dict], List[Edge]]:
    switches = []
    edges = []
    addrs = sorted(insns)
    index_of = {a:i for i,a in enumerate(addrs)}
    for addr, ins in insns.items():
        m = ADD_PC_SWITCH_RE.match(ins.text)
        if not m:
            continue
        reg = m.group(1).lower()
        idx = index_of[addr]
        cmp_n = None
        # Search a few instructions backwards for cmp same-reg,#N.
        for j in range(max(0, idx-8), idx):
            cm = CMP_IMM_RE.match(insns[addrs[j]].text)
            if cm and cm.group(1).lower() == reg:
                cmp_n = int(cm.group(2))
        if cmp_n is None or cmp_n > 128:
            continue
        sw_func = owner_function(functions, addr) or addr
        cases = []
        # At an ARM "addls pc,pc,rN,lsl#2", PC is current+8.
        # The branch table begins at addr+8 and contains cmp_n+1 branch insns.
        table_start = addr + 8
        ok = True
        for case in range(cmp_n + 1):
            ia = table_start + case*4
            bi = insns.get(ia)
            if not bi:
                ok = False
                break
            bm = BRANCH_RE.match(bi.text)
            if not bm:
                ok = False
                break
            dst = int(bm.group(1), 16)
            cases.append((case,dst))
            edges.append(Edge(sw_func, "SWITCH_CASE", dst, 0.96, f"case {case}"))
        if ok and cases:
            switches.append({"function": sw_func, "dispatch": addr, "reg": reg, "cases": cases})
    return switches, edges

def parse_runtime_facts(path: Optional[Path]) -> List[RuntimeFact]:
    if not path:
        return []
    facts = []
    for raw in path.read_text(errors="replace").splitlines():
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        # REG r0=0x1234, or REG pc=...
        m = re.match(r"^REG\s+([A-Za-z0-9_]+)\s*=\s*("+HEX+r")$", line, re.I)
        if m:
            facts.append(RuntimeFact("REG", m.group(1).lower(), None, parse_int(m.group(2)), None, raw))
            continue
        # MEM32 0xADDR=0xVALUE
        m = re.match(r"^MEM(8|16|32)\s+("+HEX+r")\s*=\s*("+HEX+r")$", line, re.I)
        if m:
            width = int(m.group(1))
            facts.append(RuntimeFact("MEM", f"MEM{width}", parse_int(m.group(2)), parse_int(m.group(3)), width, raw))
            continue
        print(f"warning: unparsed runtime fact: {raw}", file=sys.stderr)
    return facts

def ram_diff_edges(before: Optional[Path], during: Optional[Path], ram_base: int, images: List[Image]) -> List[Edge]:
    if not before or not during:
        return []
    a = before.read_bytes()
    b = during.read_bytes()
    n = min(len(a), len(b))
    edges = []
    for off in range(0, n-3, 4):
        va = struct.unpack_from("<I", a, off)[0]
        vb = struct.unpack_from("<I", b, off)[0]
        if va == vb:
            continue
        if find_image(images, vb):
            conf = 0.97 if va == 0 else 0.70
            edges.append(Edge(ram_base+off, "RAM_DIFF_POINTER", vb, conf, f"0x{va:08X} -> 0x{vb:08X}"))
    return edges

def runtime_fact_edges(facts: List[RuntimeFact], images: List[Image]) -> List[Edge]:
    edges = []
    for f in facts:
        if f.kind == "MEM" and f.addr is not None:
            conf = 1.0
            edges.append(Edge(f.addr, f"RUNTIME_{f.key}", f.value, conf, f.raw.strip()))
    return edges

def seed_from_runtime(facts: List[RuntimeFact], images: List[Image], ram_lo: int, ram_hi: int) -> Set[int]:
    seeds = set()
    for f in facts:
        if f.kind == "REG":
            # Seed code-looking register values (pc/lr are especially valuable).
            if f.key in ("pc","lr") or find_image(images, f.value):
                seeds.add(f.value)
        elif f.kind == "MEM" and f.addr is not None:
            seeds.add(f.addr)
            if find_image(images, f.value) or (ram_lo <= f.value < ram_hi):
                seeds.add(f.value)
    return seeds

def expand_graph(seeds: Set[int], edges: List[Edge], min_conf: float) -> Set[int]:
    out_adj = defaultdict(list)
    in_adj = defaultdict(list)
    for e in edges:
        if e.confidence < min_conf:
            continue
        out_adj[e.src].append(e.dst)
        in_adj[e.dst].append(e.src)
    seen = set(seeds)
    q = deque(seeds)
    while q:
        a = q.popleft()
        for b in out_adj.get(a, ()):
            if b not in seen:
                seen.add(b); q.append(b)
        for b in in_adj.get(a, ()):
            if b not in seen:
                seen.add(b); q.append(b)
    return seen

def annotate(addr: int, images: List[Image], functions: Set[int], strings: Dict[int,str], tables: Set[int], ram_lo:int, ram_hi:int) -> str:
    parts = [f"0x{addr:08X}", classify_addr(images, addr, ram_lo, ram_hi)]
    if addr in functions:
        parts.append("FUNCTION")
    if addr in tables:
        parts.append("FUNCTION_POINTER_TABLE")
    if addr in strings:
        s = strings[addr].replace("`","'")
        parts.append(("RTTI_NAME/STRING" if looks_rtti(s) else "STRING") + f" | '{s}'")
    return " | ".join(parts)

def disasm_window(insns: Dict[int,Insn], center: int, before:int=8, after:int=16) -> List[Insn]:
    addrs = sorted(insns)
    if not addrs:
        return []
    # nearest address >= center
    import bisect
    i = bisect.bisect_left(addrs, center)
    lo = max(0, i-before)
    hi = min(len(addrs), i+after)
    return [insns[a] for a in addrs[lo:hi]]

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--overlay", required=True, type=Path)
    ap.add_argument("--base", required=True, type=parse_int, help="Overlay runtime base")
    ap.add_argument("--arm9", required=True, type=Path, help="Runtime ARM9 binary, not compressed/on-disk form")
    ap.add_argument("--arm9-base", type=parse_int, default=0x02000000)
    ap.add_argument("--before", type=Path)
    ap.add_argument("--during", type=Path)
    ap.add_argument("--ram-base", type=parse_int, default=0x02000000)
    ap.add_argument("--ram-hi", type=parse_int, default=0x02400000)
    ap.add_argument("--runtime-facts", type=Path)
    ap.add_argument("--keyword", action="append", default=[])
    ap.add_argument("--seed", action="append", default=[], type=parse_int)
    ap.add_argument("--min-confidence", type=float, default=0.75)
    ap.add_argument("--objdump", default="arm-none-eabi-objdump")
    ap.add_argument("--out", type=Path, default=Path("work/re_sweep_v2/reverse_engineering_report_v2.md"))
    args = ap.parse_args()

    overlay = Image("OVERLAY", args.overlay, args.base, args.overlay.read_bytes())
    arm9 = Image("ARM9", args.arm9, args.arm9_base, args.arm9.read_bytes())
    images = [arm9, overlay]

    print("[1/11] Disassembling ARM9...")
    arm9_text = run_objdump(arm9, args.objdump)
    print("[2/11] Disassembling overlay...")
    ov_text = run_objdump(overlay, args.objdump)
    args.out.parent.mkdir(parents=True, exist_ok=True)
    (args.out.parent / "arm9.asm").write_text(arm9_text)
    (args.out.parent / "overlay.asm").write_text(ov_text)

    print("[3/11] Parsing instructions/functions...")
    insns = {}
    insns.update(parse_disassembly(arm9_text, arm9.name))
    insns.update(parse_disassembly(ov_text, overlay.name))
    functions = detect_functions(insns)

    print("[4/11] Extracting strings/RTTI...")
    strings = {}
    for img in images:
        strings.update(extract_strings(img))

    print("[5/11] Recovering calls/literals...")
    call_edges, callers = direct_call_edges(insns, functions)
    lit_edges = literal_edges(images, insns, functions)

    print("[6/11] Scanning pointer/function tables...")
    executable_ranges = [(img.base, img.end) for img in images]
    tables, table_edges = scan_pointer_runs(images, executable_ranges)
    ptr_edges = raw_pointer_edges(images)
    rtti_edges = rtti_table_edges(strings, tables)

    print("[7/11] Recovering switches...")
    switches, switch_edges = detect_switches(images, insns, functions)

    print("[8/11] Parsing runtime observations...")
    facts = parse_runtime_facts(args.runtime_facts)
    fact_edges = runtime_fact_edges(facts, images)

    print("[9/11] Comparing RAM dumps...")
    diff_edges = ram_diff_edges(args.before, args.during, args.ram_base, images)

    edges = call_edges + lit_edges + table_edges + ptr_edges + rtti_edges + switch_edges + fact_edges + diff_edges

    seeds = set(args.seed)
    # Known capture-related seeds from the current project. Harmless if unused.
    seeds.update({
        0x021018E4, 0x021066E4, 0x02106744, 0x02106BBC,
        0x02107494, 0x02117258, 0x02117388, 0x0211CEDC,
        0x0211CF08, 0x0211D980, 0x0211DB28, 0x021255CC,
        0x02041F5C,
    })
    # Keywords seed exact string addresses.
    kws = [k.lower() for k in args.keyword]
    for a,s in strings.items():
        if any(k in s.lower() for k in kws):
            seeds.add(a)
    seeds.update(seed_from_runtime(facts, images, args.ram_base, args.ram_hi))

    print("[10/11] Expanding seed-connected relationships...")
    connected = expand_graph(seeds, edges, args.min_confidence)

    out = []
    def w(s=""): out.append(s)

    w("# Cross-image reverse-engineering sweep v2")
    w()
    w(f"- ARM9: `{arm9.path}` runtime range `0x{arm9.base:08X}` - `0x{arm9.end:08X}`")
    w(f"- Overlay: `{overlay.path}` runtime range `0x{overlay.base:08X}` - `0x{overlay.end:08X}`")
    w(f"- Detected function starts: **{len(functions)}**")
    w(f"- Direct calls: **{len(call_edges)}**")
    w(f"- Literal edges: **{len(lit_edges)}**")
    w(f"- Pointer/function tables: **{len(tables)}**")
    w(f"- Switches detected: **{len(switches)}**")
    w(f"- Total relationships: **{len(edges)}**")
    w(f"- Seed-connected addresses: **{len(connected)}**")
    w(f"- Confidence threshold for graph expansion: **{args.min_confidence:.2f}**")
    w()

    w("## Runtime observations")
    w()
    if facts:
        for f in facts:
            if f.kind == "REG":
                w(f"- `REG {f.key} = 0x{f.value:08X}` → {classify_addr(images,f.value,args.ram_base,args.ram_hi)}")
            else:
                w(f"- `{f.key} 0x{f.addr:08X} = 0x{f.value:08X}` → value class {classify_addr(images,f.value,args.ram_base,args.ram_hi)}")
    else:
        w("_No runtime facts file supplied._")
    w()

    # Special high-value interpretation section: callsites around runtime PC/LR and known capture functions.
    w("## Runtime-linked disassembly windows")
    w()
    interesting = set()
    for f in facts:
        if f.kind == "REG" and f.key in ("pc","lr"):
            interesting.add(f.value)
    interesting.update(a for a in seeds if a in insns)
    for a in sorted(interesting):
        win = disasm_window(insns, a, 5, 12)
        if not win:
            continue
        w(f"### Around `0x{a:08X}`")
        w()
        w("```asm")
        for ins in win:
            mark = "=>" if ins.addr == a else "  "
            w(f"{mark} {ins.addr:08X}: {ins.text}")
        w("```")
        w()

    w("## Capture-related strings")
    w()
    capstrings = [(a,s) for a,s in strings.items() if "capture" in s.lower() or "pokemon" in s.lower()]
    for a,s in sorted(capstrings):
        w(f"- `0x{a:08X}` `{s}`")
    w()

    w("## Seeds")
    w()
    for a in sorted(seeds):
        w(f"- {annotate(a, images, functions, strings, tables, args.ram_base, args.ram_hi)}")
    w()

    w("## Automatically recovered switches")
    w()
    for sw in switches:
        if sw["function"] not in connected and not any(dst in connected for _,dst in sw["cases"]):
            continue
        w(f"### Switch in `0x{sw['function']:08X}`")
        w()
        w(f"Dispatch instruction: `0x{sw['dispatch']:08X}`")
        w(f"Index register: `{sw['reg']}`")
        w()
        for case,dst in sw["cases"]:
            w(f"- case `{case}` -> `0x{dst:08X}`")
        w()

    w("## Direct callers of seed/connected functions")
    w()
    targets = sorted(a for a in connected if a in callers)
    # Avoid a pathological report: caller lists are useful only for function-like targets.
    for dst in targets:
        if dst not in functions and dst not in seeds:
            continue
        cs = callers[dst]
        if not cs:
            continue
        w(f"### `0x{dst:08X}`")
        w()
        for src,site in sorted(cs):
            w(f"- caller `0x{src:08X}` at `0x{site:08X}`")
        w()

    w("## Connected relationships")
    w()
    by_src = defaultdict(list)
    for e in edges:
        if e.src in connected or e.dst in connected:
            by_src[e.src].append(e)
    for src in sorted(by_src):
        # Keep low-confidence edges visible, but they did not drive closure unless above threshold.
        w(f"### {annotate(src, images, functions, strings, tables, args.ram_base, args.ram_hi)}")
        w()
        for e in sorted(by_src[src], key=lambda x:(x.kind,x.dst,x.note)):
            w(f"- **{e.kind}** -> {annotate(e.dst, images, functions, strings, tables, args.ram_base, args.ram_hi)} | confidence {e.confidence:.2f}" + (f" | {e.note}" if e.note else ""))
        w()

    w("## Unresolved indirect calls in connected functions")
    w()
    for addr, ins in sorted(insns.items()):
        if ins.mnemonic != "blx":
            continue
        if re.match(r"^(r(?:1[0-5]|[0-9])|ip|lr)$", ins.operands.strip(), re.I):
            fn = owner_function(functions, addr)
            if fn in connected:
                w(f"- function `0x{fn:08X}` at `0x{addr:08X}`: `{ins.text}`")
    w()

    w("## Runtime RAM pointer changes")
    w()
    for e in diff_edges:
        w(f"- `0x{e.src:08X}` -> `0x{e.dst:08X}` | confidence {e.confidence:.2f} | {e.note}")
    w()

    w("## Notes")
    w()
    w("- This report is heuristic. `objdump -D` disassembles data as if it were code, so false function/table detections are expected.")
    w("- Direct calls and PC-relative literal loads are high-confidence; RTTI proximity and raw pointer relationships are weaker.")
    w("- Runtime observations are treated as exact facts from the supplied GDB capture, but their semantic meaning still requires interpretation.")
    w("- The main improvement over v1 is cross-image traversal: Overlay code can now lead directly into runtime ARM9 code and back through static callers/relationships.")
    w()

    args.out.write_text("\n".join(out))
    print("[11/11] Done.")
    print(args.out)

if __name__ == "__main__":
    main()
